# stm8flash.exe for win32

Compiled by: @github.com/annadostoevskaya

Compile Time/Date: Fri Apr 26 20:31:17 2024

References:
- Source code: https://github.com/vdudouyt/stm8flash.git
